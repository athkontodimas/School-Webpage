
function submission(){
    alert("Successful submission");
}

function date(){
    const date=new Date();
    const year = date.getFullYear();
    $(".date").html(year);
    
}

